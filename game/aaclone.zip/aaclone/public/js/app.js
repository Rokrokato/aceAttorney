;var case_name = "/cases/case_001/case_001.json";
var game = null;

// Main Game Class
function AceAttorneyGame(case_json) {
    this.case_json = case_json;
}

$(function() {
    $.getJSON(case_name, function(case_json) {
        $('#loading').hide();
        $('#start').show();

        game = new AceAttorneyGame(case_json);
    });

    $('#start').click(function() {
        // Run your class below
    });
});